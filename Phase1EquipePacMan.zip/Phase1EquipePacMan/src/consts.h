#ifndef CONSTS_H
#define CONSTS_H

#include "Vector3.h"

const Vector3 g = Vector3(0, 50, 0);

#endif
