# projet-matphi

Pour lancer le projet: 
- Télécharger le dossier compressé
- Créer un projet avec le Project Generator de OpenFrameWork
- Dézippé le dossier téléchargé précédemment 
- Copier-coller ou déplacer les fichiers du dossier "src" du dossier décompressé vers le dossier "src" du projet créé
- Un avertissement s'affichera pour indiquer que les fichiers ofApp.cpp et ofApp.h existent déjà
- Les remplacer par les nouveaux fichiers
- Ouvrir le projet créé
- Dans le Solution Explorer, on remarquera que les fichiers ajoutés ne sont pas présents 
- Faire un clic droit sur le dossier "src" puis faire Add > Existing Item
- Sélectionner les fichiers manquants (ne pas inclure les ofApp) et les ajouter au projet
- Lancer le projet, une fenêtre devrait s'ouvrir
- Pour lancer des projectiles, voir les notes en haut à gauche de la fenêtre